globalThis._importMeta_={url:import.meta.url,env:process.env};import 'node:http';
import 'node:https';
export { y as default } from './chunks/nitro/node-server.mjs';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
//# sourceMappingURL=index.mjs.map
